<?php

namespace Razorpay\Api;

class Iin extends Entity
{   
    public function fetch($id)
    {
        return parent::fetch($id);
    }
}
